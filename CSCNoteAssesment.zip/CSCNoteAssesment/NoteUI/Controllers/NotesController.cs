﻿using Microsoft.AspNetCore.Mvc;
using NoteDALayer.Interfaces;
using NotesEntities;

namespace NoteUI.Controllers
{
    public class NotesController : Controller
    {
        private readonly INoteRepository _repo;

        public NotesController(INoteRepository repo)
        {
            _repo = repo;
        }

        public async Task<IActionResult> Index()
        {
            var notes = await _repo.GetAllNotesAsync();
            return View(notes);
        }

        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Note note)
        {

            if (ModelState.IsValid)
            {

                await _repo.CreateNoteAsync(note);
                return RedirectToAction(nameof(Index));
            }
            return View(note);
        }

        public async Task<IActionResult> Edit(Guid id)
        {
            var note = await _repo.GetNoteByIdAsync(id);
            if (note == null) return NotFound();
            return View(note);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Note note)
        {
            if (ModelState.IsValid)
            {
                await _repo.UpdateNoteAsync(note);
                return RedirectToAction(nameof(Index));
            }
            return View(note);
        }

        public async Task<IActionResult> Delete(Guid id)
        {
            await _repo.DeleteNoteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}