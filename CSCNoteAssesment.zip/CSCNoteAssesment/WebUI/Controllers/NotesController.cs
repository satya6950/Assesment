﻿using Microsoft.AspNetCore.Mvc;
using NoteDALayer.Interfaces;
using NotesEntities;

namespace WebUI.Controllers
{
    public class NotesController : Controller
    {
        private readonly INoteRepository _repo;

        public NotesController(INoteRepository repo)
        {
            _repo = repo;
        }

        public async Task<IActionResult> Index()
        {
            var notes = await _repo.GetAllNotesAsync();
            return View(notes);
        }

        [HttpPost]
        public async Task<IActionResult> Create(string title, string content)
        {
            if (string.IsNullOrWhiteSpace(title)) return RedirectToAction(nameof(Index));
            await _repo.CreateNoteAsync(new Note { Title = title, Content = content });
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, string title, string content)
        {
            var note = await _repo.GetNoteByIdAsync(id);
            if (note != null)
            {
                note.Title = title;
                note.Content = content;
                await _repo.UpdateNoteAsync(note);
            }
            return RedirectToAction(nameof(Index));
        }
        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            await _repo.DeleteNoteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
