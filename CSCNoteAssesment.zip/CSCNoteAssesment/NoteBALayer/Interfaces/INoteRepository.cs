﻿using NotesEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoteDALayer.Interfaces
{
    public interface INoteRepository
    {

        Task<IEnumerable<Note>> GetAllNotesAsync();
        Task<Note?> GetNoteByIdAsync(Guid id);
        Task<Note> CreateNoteAsync(Note note);
        Task<Note?> UpdateNoteAsync(Note note);
        Task<bool> DeleteNoteAsync(Guid id);



    }
}
